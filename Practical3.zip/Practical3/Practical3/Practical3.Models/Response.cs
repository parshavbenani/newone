﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace IdentityCoreWebApi.Models
{
    public class Response
    {
        [Key]
        [JsonIgnore]
        public int Id { get; set; }
        public string Status { get; set; }
        public string Meessage { get; set; }
    }
}
