﻿using IdentityCoreWebApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Practical3.DataAccess.Repository.IRepository;
using Practical3.Models;
using Practical3.Models.ViewModels;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Xml.Linq;
using static Practical3.Models.Order;

namespace Practical3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AddOrderController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<IdentityUser> _userManager;
        //private readonly RoleManager<IdentityRole> _roleManager;
        //private readonly IConfiguration _configuration;
        public AddOrderController(IUnitOfWork unitOfWork,UserManager<IdentityUser> userManager/*, RoleManager<IdentityRole> roleManager, IConfiguration configuration*/)
        {
            _userManager = userManager;
            //_roleManager = roleManager;
            //_configuration = configuration;
            _unitOfWork = unitOfWork;
        }
        [HttpPost]
        [AllowAnonymous]
        [Route("Add OrderItem")]
        public async Task<ActionResult> Post(OrderVM model,StatusType statusType)
        {
            // Check if user exists
            var user = await _userManager.GetUserAsync(User);
            //if (user == null)
            //{
            //    return Unauthorized();
            //}

            // Add order to the repository
            var order = new Order
            {
                OrderDate = DateTime.Now,
                Note = model.Note,
                DiscountAmount = model.DiscountAmount,
                Status = statusType,
                TotalAmount = 0,
                CustomerName = model.CustomerName,
                CustomerEmail = string.IsNullOrEmpty(model.CustomerEmail) ? user.Email : model.CustomerEmail,
                CustomerContactNo = model.CustomerContactNo,
                IsActive = true,
                CreatedOn = DateTime.Now,
                ModifiedOn = DateTime.Now
            };
            _unitOfWork.Order.Add(order);
            _unitOfWork.Save();

            // Add order items to the repository
            var orderItems = new List<OrderItems>();
            var amount = 0.0;
            foreach (var item in model.OrderItems)
            {
                
                var product = _unitOfWork.Product.GetFirstOrDefault(x => x.ProductId == item.ProductId);
                if (product == null)
                {
                    return BadRequest($"Product with id {item.ProductId} not found");
                }
                if (product.Quantity < item.Quantity)
                {
                    return BadRequest($"Product with id {item.ProductId} does not have enough quantity");
                }
                var orderItem = new OrderItems
                {
                    OrderId = order.OrderId,
                    ProductId = product.ProductId,
                    Quantity = item.Quantity,
                    Price = product.Price,
                    IsActive = item.IsActive
                };
                product.Quantity-= orderItem.Quantity;
                amount= orderItem.Price*orderItem.Quantity;
                orderItems.Add(orderItem);
            }
            foreach (var item in orderItems)
            {
                _unitOfWork.OrderItems.Add(item);
            }
            order.TotalAmount= amount-order.DiscountAmount;
            _unitOfWork.Save();
            return Ok(new {OrderId = order.OrderId});
        }

        [HttpGet]
        [Route("Filters")]
        public IActionResult GetAllOrders(DateTime? fromDate, DateTime? toDate, StatusType? statusType, string? customerSearch)
        {

            // Get orders
            var orders = _unitOfWork.Order.GetAll();

            //filters
            if (fromDate != null)
            {
                orders = orders.Where(o => o.CreatedOn >= fromDate.Value);
            }
            if (toDate != null)
            {
                orders = orders.Where(o => o.CreatedOn <= toDate.Value);
            }
            if (statusType != null)
            {
                orders = orders.Where(o => o.Status == statusType.Value);
            }
            if (!string.IsNullOrEmpty(customerSearch))
            {
                orders = orders.Where(o => o.CustomerName.ToLower().Contains(customerSearch.ToLower())
                                     || o.CustomerEmail.ToLower().Contains(customerSearch.ToLower())
                                     || o.CustomerContactNo.ToLower().Contains(customerSearch.ToLower()));
            }

            var orderViewModels = orders.Select(o => new Order
            {
                OrderId = o.OrderId,
                CreatedOn = o.CreatedOn,
                CustomerName = o.CustomerName,
                CustomerEmail = o.CustomerEmail,
                CustomerContactNo = o.CustomerContactNo,
                Status = o.Status,
                TotalAmount = o.TotalAmount,
                DiscountAmount = o.DiscountAmount,
                Note = o.Note
            }).ToList();

            return Ok(orderViewModels);
        }

        [HttpGet]
        [Route("GetOrderById")]
        public IActionResult GetOrderById(int id)
        {
            var detailsToShow = (from t1 in _unitOfWork.Order.GetAll() join t2 in _unitOfWork.OrderItems.GetAll() 
                                on t1.OrderId equals t2.OrderId
                                where t2.OrderId == id 
                                group t2 by t1 into temp 
                                select new {order=temp.Key,orderdetails = temp.ToArray()}).ToList();
            return Ok(detailsToShow);
        }

        [HttpPut]
        [Route("Update Order Status")]
        public IActionResult UpdateOrderStatus(int orderid, StatusType? statusType)
        {
            var order = _unitOfWork.Order.GetFirstOrDefault(o => o.OrderId == orderid);
            if (order.IsActive != false)
            {
                if (order.Status > statusType.Value)
                {
                    return BadRequest($"Order Status InValid {order.Status}");
                }
                else 
                { 
                    order.Status = statusType.Value;
                    _unitOfWork.Order.Update(order);
                    _unitOfWork.Save(); 
                }
            }
            return Ok(order);

        }
        [HttpPut]
        [Route("InActive Order")]
        public IActionResult InActiveOrder(int orderid)
        {
            var order = _unitOfWork.Order.GetFirstOrDefault(o => o.OrderId == orderid);
            order.IsActive = true;

            _unitOfWork.Order.Update(order);
            _unitOfWork.Save();

            return Ok(order);

        }

        [HttpDelete]
        [Route("RemoveOrderItems")]
        public IActionResult RemoveOrderItems(int orderid)
        {
            var orderitem = _unitOfWork.OrderItems.GetAll();
            var deletelist = orderitem.Where(x => x.OrderId == orderid).ToList();
            _unitOfWork.OrderItems.RemoveRange(deletelist);
            _unitOfWork.Save();

            var orderdata = _unitOfWork.Order.GetFirstOrDefault(x => x.OrderId == orderid);
            orderdata.TotalAmount = 0;
            _unitOfWork.Order.Update(orderdata);
            _unitOfWork.Save();
            return Ok(new Response() { Status="Success",Meessage = "Order Deleted Successfully" });

        }

        [HttpPut]
        [Route("UpdateOrderItemQuantity")]
        public IActionResult UpdateOrderItemQuantity(int Quantity, int orderItemId)
        {
            var upQuantity = _unitOfWork.OrderItems.GetFirstOrDefault(x => x.OrderItemId == orderItemId);

            if (Quantity >= 1 && upQuantity.IsActive != false)
            {
                upQuantity.Quantity = Quantity;
                _unitOfWork.OrderItems.Update(upQuantity);
                _unitOfWork.Save();
            }
            else
            {
                return Ok(new Response() { Status = "Error",Meessage = "Quantity must be 1" });
            }
            return Ok(new Response() { Status = "Success", Meessage = "OrderItem Updated Successfully" });

        }
    }
}
