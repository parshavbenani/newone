﻿using Practical4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Repository.IRepository
{
    public interface IAddressRepository
    {
       public IEnumerable<Address> GetAll();
       Task<Address> Add(Address address);
        Address GetFirstOrDefault(Expression<Func<Address, bool>> filter);
        void Update(Address obj);


    }
}
