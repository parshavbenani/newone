﻿using AzureFunction.DAL.Data;
using AzureFunction.DAL.IRepository;
using AzureFunction.DAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunction.DAL.Repository
{
    public class ProductRepository:IProducts
    {
        private readonly ApplicationDbContext _context;

        public ProductRepository(ApplicationDbContext context)
        {
            _context = context; 
        }

        public async Task<response> GetProducts(int Id)
        {
            try
            {
                return new response { Data = _context.Products.Where(x=> x.ProductId == Id).ToList(), Message = "Success", Status = "Success" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }

        public async Task<response> GetProductsList()
        {
            try
            {
                return new response { Data = _context.Products.ToList(), Message = "Success", Status = "Success" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
