﻿using AzureExam.Models.Models;
using AzureExam.Models.ViewModels;
using AzureFunction.DAL.Data;
using AzureFunction.DAL.IRepository;
using AzureFunction.DAL.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunction.DAL.Repository
{
    public class UserRepository : IUsers
    {
        public async Task<response> LogIn(loginDto User)
        {
            try
            {
                if(User.UserName == "jainam" && User.Password == "Jainam@123")
                {
                    var token = "eyJhbGciOiJIUzI1NiJ9.eyJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6ImphaW5hbSIsImV4cCI6MTY4NTAxMTI2MiwidXNlcklkIjoiNTI1MzNkZDktMzhlNi00MmI3LTgwYWQtYWY4ZmVjNDIwZmY4IiwiaWF0IjoxNjg1MDExMjYyfQ.raSw5fLHMnrZ_wQTv3LjggG6teARSVWwdUzc9nS_jqw";
                    return new response { Data = token, Message = "Logged in successfully", Status = "Success" };   
                }
                return new response { Data = "", Message = "Invalid Username or password", Status = "Error" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}

