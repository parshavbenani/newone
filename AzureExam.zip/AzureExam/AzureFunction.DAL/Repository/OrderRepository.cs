﻿using AzureExam.Models;
using AzureExam.Models.Models;
using AzureExam.Models.ViewModels;
using AzureFunction.DAL.Data;
using AzureFunction.DAL.IRepository;
using AzureFunction.DAL.ViewModels;
using Microsoft.AspNetCore.Mvc.Formatters.Xml;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static AzureExam.Models.ViewModels.global;

namespace AzureFunction.DAL.Repository
{
    public class OrderRepository:IOrder
    {
        private readonly ApplicationDbContext _context;
        public OrderRepository(ApplicationDbContext context)
        {
            _context = context; 
        }

        public async Task<response> UpdateStatus(int OrderId, global.status status)
        {
            try
            {
                response response = new response();
                var currentStatus = getStatus(OrderId);
                //if status is shipped than status can only change as paid
                if (currentStatus == global.status.Shipped)
                {
                    if (status == global.status.Paid)
                    {
                        return UpdateStatusOnDb(OrderId, status);
                    }
                    else
                    {
                        return new response { Data = "", Message = "Status Cannot update", Status = "Error" };
                    }
                }
                //if status is paid than status can not change
                else if(currentStatus == global.status.Paid)
                {
                    return new response { Data = "", Message = "Status Cannot update", Status = "Error" };
                }
                else
                {
                    return UpdateStatusOnDb(OrderId, status);
                }
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }

        public async Task<response> AddDraftOrder(DraftOrderDto draftOrder)
        {
            try
            {
                int total = 0;
                var isUserExist = _context.aspnetusers.Where(x => x.Email == draftOrder.BillingAddress.ContactEmail).ToList();
                if (isUserExist.Any())
                {
                    return new response { Data = "", Message = "User already exist with this email", Status = "Error" };
                }
                //Calculating total
                foreach (var item in draftOrder.Products)
                {
                    var isProductExist = _context.Products.Where(x => x.ProductId == item.ProductId).ToList();
                    if (isProductExist.Any())
                    {
                        if (isProductExist.FirstOrDefault().ProductQty != 0 ||
                            isProductExist.FirstOrDefault().ProductQty >= item.ProductQty)
                        {
                            total += isProductExist.FirstOrDefault().ProductPrice * item.ProductQty;
                        }
                        else
                        {
                            return new response { Data = "", Message = "Enter valid Qty for this product", Status = "Error" };
                        }
                    }
                    else
                    {
                        return new response { Data = "", Message = "No product found with this productId", Status = "Error" };
                    }
                }

                Console.WriteLine(total);
                //Creating order
                var order = new Order()
                {
                    OrderDate = DateTime.Now,
                    Note = draftOrder.Note,
                    DisountAmount = draftOrder.DisountAmount,
                    StatusType = global.status.Open,
                    CustomerName = draftOrder.BillingAddress.ContactPerson,
                    CustomerEmail = draftOrder.BillingAddress.ContactEmail,
                    CustomerContactNo = draftOrder.BillingAddress.ContactNo,
                    IsActive = draftOrder.IsActive,
                    TotalAmount = total,
                    CreatedOn = DateTime.Now
                };
                await _context.Orders.AddAsync(order);
                _context.SaveChanges();

                //Creating orderItem
                var getOrder = _context.Orders.Where(x => x.CustomerEmail == draftOrder.BillingAddress.ContactEmail).FirstOrDefault();
                if (getOrder != null)
                {
                    int id = getOrder.OrderId;
                    foreach (var item in draftOrder.Products)
                    {
                        var orderItem = new OrderItem()
                        {
                            Qty = item.ProductQty,
                            OrderId = id,
                            ProductId = item.ProductId,
                            isActive = draftOrder.IsActive,
                            price = _context.Products.Where(x => x.ProductId == item.ProductId).FirstOrDefault().ProductPrice
                        };
                        await _context.OrderItems.AddAsync(orderItem);
                        _context.SaveChanges();
                    }
                }
                //Creating Billing Address
                var bAddress = new address()
                {
                    HouseNo = draftOrder.BillingAddress.HouseNo,
                    Country = draftOrder.BillingAddress.Country,
                    State = draftOrder.BillingAddress.State,
                    City = draftOrder.BillingAddress.City,
                    ZipCode = int.Parse(draftOrder.BillingAddress.ZipCode),
                    ContactPerson = draftOrder.BillingAddress.ContactPerson,
                    ContactEmail = draftOrder.BillingAddress.ContactEmail,
                    ContactNo = draftOrder.BillingAddress.ContactNo,
                    AddressType = global.AddressType.Billing
                };
                await _context.Address.AddAsync(bAddress);
                //Creating Shipping Address
                var sAddress = new address()
                {
                    HouseNo = draftOrder.ShippingAddress.HouseNo,
                    Country = draftOrder.ShippingAddress.Country,
                    State = draftOrder.ShippingAddress.State,
                    City = draftOrder.ShippingAddress.City,
                    ZipCode = int.Parse(draftOrder.ShippingAddress.ZipCode),
                    ContactPerson = draftOrder.ShippingAddress.ContactPerson,
                    ContactEmail = draftOrder.ShippingAddress.ContactEmail,
                    ContactNo = draftOrder.ShippingAddress.ContactNo,
                    AddressType = global.AddressType.Shipping
                };

                await _context.Address.AddAsync(sAddress);
                _context.SaveChanges();
                //creating orderAddress
                var orderAddress = new OrderAddress()
                {
                    OrderId = getOrder.OrderId,
                    BillingAddressId = _context.Address.Where(x=>x.ContactEmail == draftOrder.BillingAddress.ContactEmail && x.AddressType== global.AddressType.Billing).FirstOrDefault().AddressId,
                    ShippingAddressId = _context.Address.Where(x => x.ContactEmail == draftOrder.BillingAddress.ContactEmail && x.AddressType == global.AddressType.Shipping).FirstOrDefault().AddressId
                };

                await _context.OrderAddress.AddAsync(orderAddress);
                _context.SaveChanges();

                return new response { Data = "", Message = "Record Added Successfully", Status = "Success" };
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }

        public async Task<response> GetFilterdOrders(OrderFilter filter)
        {
            try
            {
                var TodaysDate = DateTime.Now;
                if(filter.fromDate == null)
                {
                    if(TodaysDate.Day < 5)
                    {
                        filter.fromDate = TodaysDate.AddMonths(-1);
                    }
                    else
                    {
                        filter.fromDate = TodaysDate;
                    }
                }
                if(filter.toDate == null)
                {
                    filter.toDate = TodaysDate;
                }
                response response = new response();
                List<Order> orders = await _context.Orders.ToListAsync();
                List<OrderItem> orderItems = await _context.OrderItems.ToListAsync();
                List<OrderAddress> OrderAddress = await _context.OrderAddress.ToListAsync();
                List<address> AddressList = await _context.Address.ToListAsync();
                List<Product> ProductList = await _context.Products.ToListAsync();

                var filterdData = (from o in orders
                                   join oi in orderItems on o.OrderId equals oi.OrderId
                                   join oa in OrderAddress on o.OrderId equals oa.OrderId
                                   join a in AddressList on oa.ShippingAddressId equals a.AddressId
                                   join p in orderItems on oi.ProductId equals p.ProductId
                                   where
                                   (o.OrderDate.Date >= filter.fromDate.Value.Date && o.OrderDate.Date <= filter.toDate.Value.Date) ||
                                   o.StatusType.ToString().Equals(filter.statusType.ToString()) ||
                                   (o.CustomerName == filter.customerName ||
                                   o.CustomerEmail == filter.customerEmail) ||
                                   o.IsActive == filter.isActive || 
                                   oi.ProductId == filter.productId
                                   select new
                                   {
                                       o.OrderId,
                                       o.Note,
                                       o.CustomerName,
                                       o.CustomerEmail,
                                       p.ProductId,
                                       Status = Convert(o.StatusType).ToString(),
                                       o.TotalAmount,
                                       adddress = string.Join(',', a.HouseNo, a.City, a.State, a.Country, a.ZipCode)
                                   }).ToList().Distinct();


                //var connection = new MySqlConnection(Environment.GetEnvironmentVariable("con").ToString());
                //var command = new MySqlCommand();
                //command = new MySqlCommand("SELECT orders.OrderId,orders.Note,orders.CustomerName,orders.CustomerEmail,orders.TotalAmount," +
                //                            " address.AddressStreet,address.State " +
                //                            " FROM orders as orders,address as address,orderaddress as orderaddress "+
                //                            "WHERE orderaddress.ShippingAddressId=address.AddressId AND" +
                //                            "orders.IsActive = " + filter.isActive + " and " +
                //                            "orders.StatusType = " + filter.statusType + " and " +
                //                            "orders.CustomerName = " + filter.customerName + " and " +
                //                            "orders.CustomerEmail = " + filter.customerEmail + ";" , connection);
                //var reader = command.ExecuteReader();
                //while (reader.Read())
                //{
                //    //values.Add(new ProCat()
                //    //{
                //    //}
                //};
                response.Data = filterdData.ToList();
                response.Message = "Success";
                response.Status = "Success";
                return response;
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }

        }
        private global.status getStatus(int id)
        {
            var orders = _context.Orders.Where(x => x.OrderId == id).FirstOrDefault();
            if(orders == null)
            {
                throw new Exception ("No Order found with this orderId");
            }
            global.status status = new global.status();
            status = orders.StatusType;
            return status;
        }

        private response UpdateStatusOnDb(int OrderId, global.status status)
        {
            response response = new response();
            var isExistData = _context.Orders.Where(x => x.OrderId == OrderId).ToList();
            isExistData.ForEach(x =>
            {
                x.StatusType = status;
                _context.Orders.Update(x);
            });
            _context.SaveChanges();

            response.Data = "";
            response.Message = "Status updated Successfully";
            response.Status = "Success";
            return response;
        }

        private global.status Convert(global.status status)
        {
            return (global.status)Enum.ToObject(typeof(global.status), status);
        }
    }
}
