﻿using AzureExam.Models.ViewModels;
using AzureFunction.DAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunction.DAL.IRepository
{
    public interface IOrder
    {
        public Task<response> UpdateStatus(int OrderId,global.status status);
        public Task<response> AddDraftOrder(DraftOrderDto draftOrder);
        public Task<response> GetFilterdOrders(OrderFilter order);
    }
}
