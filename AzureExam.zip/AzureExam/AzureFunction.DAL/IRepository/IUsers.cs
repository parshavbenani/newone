﻿using AzureExam.Models.ViewModels;
using AzureFunction.DAL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunction.DAL.IRepository
{
    public interface IUsers
    {
        public Task<response> LogIn(loginDto User);
    }
}
