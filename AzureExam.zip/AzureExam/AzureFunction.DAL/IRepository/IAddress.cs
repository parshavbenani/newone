﻿using AzureExam.Models.Models;
using AzureExam.Models.ViewModels;
using AzureFunction.DAL.ViewModels;

namespace AzureFunction.DAL.IRepository
{
    public interface IAddress
    {
        public Task<response> GetAddressList(string email);
        public Task<response> AddAddressForUser(AddAddressViewModel address);
        public Task<response> UpdateOrderAddress(UpdateAddressDto address);
    }
}
