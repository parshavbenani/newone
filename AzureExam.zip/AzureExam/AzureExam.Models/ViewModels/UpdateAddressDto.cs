﻿using AzureExam.Models.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureExam.Models.ViewModels
{
    public class UpdateAddressDto
    {
        [Required]
        public int OrderAddressId { get; set; }
        [Required]
        public global.AddressType AddressChangeType { get; set; }
        public AddAddressViewModel Address { get; set; }
    }
}
