﻿using AzureExam.Models.ViewModels;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AzureExam.Models.Models
{
    public class address
    {
        [Key]
        public int AddressId { get; set; }
        [Required]
        public string HouseNo { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [MaxLength(6),Required]
        public int ZipCode { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [MinLength(10),MaxLength(10),Required]
        public string ContactNo { get; set; }
        [Required]
        public string ContactEmail { get; set; }
        [ForeignKey("aspnetusers")]
        public string? userId { get; set; }
        [Required]
        public global.AddressType AddressType { get; set; }
    }
}
