﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace AzureExam.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        [Required]
        [Range(1, 5000, ErrorMessage = "Enter price between 0 to 5000")]
        public int ProductPrice { get; set; }
        [Required]
        [Range(1, 1000, ErrorMessage = "Enter Qty between 0 to 1000")]
        public int ProductQty { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public DateTime ModifiedOn { get; set; } = DateTime.Now;
    }
}
