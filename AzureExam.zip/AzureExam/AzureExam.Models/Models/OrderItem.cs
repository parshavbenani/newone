﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;

namespace AzureExam.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int Qty { get; set; }
        public int price { get; set; }
        public bool isActive { get; set; }
        [ForeignKey("Order")]
        public int OrderId { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }

    }
}
