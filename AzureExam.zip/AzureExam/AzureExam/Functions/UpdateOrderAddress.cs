using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureFunction.DAL.IRepository;
using AzureExam.Models.Models;
using AzureExam.Models.ViewModels;
using AzureFunction.DAL.ViewModels;

namespace AzureExam.Functions
{
    public class UpdateOrderAddress
    {
        private readonly IAddress _address;
        public UpdateOrderAddress(IAddress address)
        {
            _address = address;
        }
        [FunctionName("UpdateOrderAddress")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                //1 for Shipping
                //2 for billing
                UpdateAddressDto UpdateAddress = new UpdateAddressDto();
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                UpdateAddress = JsonConvert.DeserializeObject<UpdateAddressDto>(content);

                return await _address.UpdateOrderAddress(UpdateAddress);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
