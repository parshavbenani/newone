using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureExam.Models.Models;
using Microsoft.IdentityModel.Tokens;
using AzureExam.Models.ViewModels;
using AzureFunction.DAL.IRepository;
using AzureFunction.DAL.ViewModels;

namespace AzureExam.Functions
{
    public class AddAddress
    {
        private readonly IAddress _address;
        public AddAddress(IAddress address)
        {
            _address = address;
        }

        [FunctionName("AddAddress")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            AddAddressViewModel address = new AddAddressViewModel();
            log.LogInformation("C# HTTP trigger function processed a request.");

            var content = await new StreamReader(req.Body).ReadToEndAsync();
            address = JsonConvert.DeserializeObject<AddAddressViewModel>(content);
           return await _address.AddAddressForUser(address: address);

        }
    }
}
