using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureFunction.DAL.ViewModels;
using AzureFunction.DAL.IRepository;
using AzureExam.Models.ViewModels;

namespace AzureExam.Functions
{
    public  class getOrders
    {
        private readonly IOrder _order;

        public getOrders(IOrder order)
        {
            _order = order;
        }

        [FunctionName("getOrders")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {

            try
            {
                OrderFilter order = new OrderFilter();
                var content = await new StreamReader(req.Body).ReadToEndAsync();
                order = JsonConvert.DeserializeObject<OrderFilter>(content);

                return await _order.GetFilterdOrders(order);
            }
            catch (Exception ex)
            {
                return new response { Data = ex.Message.ToString(), Message = "Exception", Status = "Error" };
            }
        }
    }
}
