using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureFunction.DAL.ViewModels;
using AzureFunction.DAL.Repository;
using AzureFunction.DAL.IRepository;
using System.Xml.Linq;

namespace AzureExam.Functions
{
    public class GetAddressList
    {
        private readonly IAddress _address;
        public GetAddressList(IAddress address)
        {
            _address = address;
        }

        [FunctionName("GetAddressList")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
            ILogger log)
        {

            log.LogInformation("C# HTTP trigger function processed a request.");
            string email = req.Query["email"];
            return await _address.GetAddressList(email:email);
        }
    }
}
