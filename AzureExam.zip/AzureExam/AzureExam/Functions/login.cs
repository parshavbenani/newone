using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureExam.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using AzureFunction.DAL.IRepository;
using AzureFunction.DAL.ViewModels;

namespace AzureExam.Functions
{
    public class login
    {
        private readonly IUsers _user;

        public login(IUsers users)
        {
            _user= users;
        }

        [FunctionName("login")]
        public async Task<response> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            loginDto userCred= new loginDto();
            var content = await new StreamReader(req.Body).ReadToEndAsync();
            userCred = JsonConvert.DeserializeObject<loginDto>(content);
            return await _user.LogIn(User:userCred);

        }
    }
}
